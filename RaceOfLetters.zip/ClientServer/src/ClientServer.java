import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class ClientServer{
	static int let = 0;
	static int number = 0;
	static boolean yes = false;
	static int results[];
	static int winner;
	static String resultation;
	static int realnumber;
	public class oneServer  implements Runnable
	{
		Socket sock;
		BufferedReader reader; 
		int sin;
	public oneServer (Socket clientSocket1)
	{
			try
			{
			sock=clientSocket1;
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
	}
		@Override
		public void run() 
		{
			try
			{
				InputStream in=sock.getInputStream();
				OutputStream out=sock.getOutputStream();
				DataInputStream in1 = new DataInputStream(in);
				DataOutputStream out1=new DataOutputStream(out);
				int input=0;
				int place=0;
				input=in1.readInt();
				results[number]=input;
			    number=number+1;
				System.out.println("Score of"+" "+number+"person is"+" " + input);
					if(number!=0)
					{
						System.out.println("Результаты:");
						int z=0;
						int i=1;
							for(int t=0;t<results.length;t++)
							{
								for(int s=0;s<results.length;s++)
								{
									if(results[s]<results[t])
									{
										z=results[s];
										results[s]=results[t];
										results[t]=z;
									}
				
								}	
							}
				winner=results[0];
						for(i=0;i<results.length;i++)
						{
							System.out.println(i+1+"место:"+results[i]+"с/м");
							resultation=Integer.toString(results[i]);
						}
					}
				out1.writeInt(winner);
				out1.flush();
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
			}
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new ClientServer().go();
	}
	public void go()
	{
		try{
			ServerSocket serverSock1=new ServerSocket(444);
			System.out.println("got a connection");
			results=new int[5];
			resultation=new String();
				while(true)
				{
					Socket clientSocket=serverSock1.accept(); 
					Thread t=new Thread(new oneServer(clientSocket)); 
					t.start();
					System.out.println("got a connection1");		
				}
		}
		catch(Exception ex)
		{
			System.err.println("Exception in run's main loop");
			ex.printStackTrace();
		}
	}

}
